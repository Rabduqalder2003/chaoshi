# --- 1. SILENT ADMIN CHECK ---
$null = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if ($null -eq $false) {
    $arguments = "-File `"$($MyInvocation.MyCommand.Definition)`""
    [void](Start-Process powershell -Verb runAs -ArgumentList $arguments)
    Exit
}

# --- 2. WARNING MESSAGE BOXES ---
Add-Type -AssemblyName System.Windows.Forms

# Epilepsy Warning
[System.Windows.Forms.MessageBox]::Show("If you have epilepsy, or something like that, I would recommend not running this file", "Warning", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)

# Reassurance Warning
[System.Windows.Forms.MessageBox]::Show("If your scared about this thing destroying your computer, it wont. Press ok to start.", "Notice", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)

# --- 3. PRE-FLIGHT (Chaos Starts Here) ---
$objShell = New-Object -ComObject WScript.Shell
for ($i = 0; $i -lt 50; $i++) { $objShell.SendKeys([char]175) }
[void](New-Object -ComObject Shell.Application).MinimizeAll()

# --- 4. GDI & SYSTEM API SETUP ---
[void](Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class GDI {
    [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr hwnd);
    [DllImport("gdi32.dll")] public static extern bool BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, uint dwRop);
    [DllImport("user32.dll")] public static extern bool InvertRect(IntPtr hDC, ref RECT lprc);
    [DllImport("user32.dll")] public static extern bool RedrawWindow(IntPtr hWnd, IntPtr lprcUpdate, IntPtr hrgnUpdate, uint flags);
    [DllImport("user32.dll")] public static extern bool DrawIcon(IntPtr hDC, int x, int y, IntPtr hIcon);
    [DllImport("user32.dll")] public static extern IntPtr LoadIcon(IntPtr hInstance, IntPtr lpIconName);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
}
"@ -ErrorAction SilentlyContinue)

$hdc = [GDI]::GetDC([IntPtr]::Zero)
$scrW = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width
$scrH = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height
$rect = New-Object GDI+RECT; $rect.Left = 0; $rect.Top = 0; $rect.Right = $scrW; $rect.Bottom = $scrH
$player = New-Object System.Media.SoundPlayer
$errorIcon = [GDI]::LoadIcon([IntPtr]::Zero, [IntPtr]32513)

# --- 5. THE PAYLOAD ENGINE ---
function Execute-Payload($id, $duration) {
    $wavPath = Join-Path $PSScriptRoot "$id.wav"
    if (Test-Path $wavPath) {
        $player.SoundLocation = $wavPath
        $player.Load()
        $player.PlayLooping()
    }

    if ($id -eq 5) { Stop-Process -Name "explorer" -Force -ErrorAction SilentlyContinue }
    
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $bx=100; $by=100; $bdx=70; $bdy=70 

    while ($sw.Elapsed.TotalSeconds -lt $duration) {
        if ($id -ge 2) {
            $mX = [System.Windows.Forms.Cursor]::Position.X + (Get-Random -Min -50 -Max 50)
            $mY = [System.Windows.Forms.Cursor]::Position.Y + (Get-Random -Min -50 -Max 50)
            [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($mX, $mY)
            [void]([GDI]::DrawIcon($hdc, $mX, $mY, $errorIcon))
        }

        switch ($id) {
            1 { [void]([GDI]::BitBlt($hdc, (Get-Random -Max 30), (Get-Random -Max 30), $scrW, $scrH, $hdc, 0, 0, 0x00CC0020)) }
            2 { 
                [void]([GDI]::InvertRect($hdc, [ref]$rect))
                [void]([GDI]::BitBlt($hdc, (Get-Random -Min -150 -Max 150), 0, $scrW, $scrH, $hdc, 0, 0, 0x00CC0020))
                if ($sw.Elapsed.Milliseconds % 20 -eq 0) { [System.Windows.Forms.SendKeys]::SendWait([char](Get-Random -Min 33 -Max 126)) }
            }
            3 { 
                $bx += $bdx; $by += $bdy
                if($bx -le 0 -or $bx -ge ($scrW - 500)) {$bdx = -$bdx}
                if($by -le 0 -or $by -ge ($scrH - 500)) {$bdy = -$bdy}
                [void]([GDI]::BitBlt($hdc, $bx, $by, 600, 600, $hdc, 0, 0, 0x00CC0020))
                if ($sw.Elapsed.Milliseconds % 50 -eq 0) { [void]([GDI]::InvertRect($hdc, [ref]$rect)) }
            }
            4 { 
                [void]([GDI]::BitBlt($hdc, (Get-Random -Min -5 -Max 5), 25, $scrW, $scrH, $hdc, 0, 0, 0x00CC0020))
                [void]([GDI]::BitBlt($hdc, (Get-Random -Max $scrW), 0, 200, $scrH, $hdc, (Get-Random -Max $scrW), 0, 0x001100A6))
            }
            5 { 
                [void]([GDI]::InvertRect($hdc, [ref]$rect))
                [void]([GDI]::BitBlt($hdc, (Get-Random -Min -250 -Max 250), (Get-Random -Min -250 -Max 250), $scrW, $scrH, $hdc, 0, 0, 0x00CC0020))
                [void]([GDI]::BitBlt($hdc, $bx, $by, 800, 800, $hdc, 0, 0, 0x00EE0086))
            }
        }
        Start-Sleep -m 5
    }
    $player.Stop()
}

# --- 6. EXECUTION ---
for ($i=1; $i -le 5; $i++) { Execute-Payload $i 30 }

# --- 7. CLEANUP & RESTORE ---
[void]([GDI]::RedrawWindow([IntPtr]::Zero, [IntPtr]::Zero, [IntPtr]::Zero, 0x0085))
Start-Sleep -Seconds 3
[void](Start-Process "explorer.exe")